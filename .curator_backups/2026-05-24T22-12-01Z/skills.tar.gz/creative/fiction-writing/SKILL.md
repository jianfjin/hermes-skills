---
name: fiction-writing
description: Write long-form cultivation/programmer fiction with code-as-worldbuilding — chapter continuity, markdown formatting, and the user's specific xianxia-meets-software-engineering prose style.
version: 1.0.0
---

# Fiction Writing (Cultivation × Programmer)

Write serialized long-form fiction in the user's established universe: xianxia cultivation world where the "system" is literally a distributed codebase, architecture is a martial art, and code comments are encrypted messages from ancient masters.

## Project Location

`~/projects/flying-programmer/` — current novel: 《渡劫期大圆满程序员飞升记》

Chapter files: `chapter-01.md`, `chapter-02.md`, ..., `chapter-{n}-fin.md` (final chapter).

## Workflow

### Before Writing a New Chapter

1. **Read ALL prior chapters first.** Full context is essential — characters, plot threads, running jokes, and the code-as-worldbuilding mechanics carry across chapters. Use `read_file` on each file.

2. **Re-read the previous chapter's ending carefully.** The next chapter's opening must flow from exactly where the prior chapter left characters and events.

3. **Honor the chapter preview** at the end of the prior chapter. The next chapter must deliver what was promised, even if it also adds more.

### Writing the Chapter

1. **Write to file, never to terminal.** The user explicitly prefers long-form creative content saved to file.

2. **Chapter header format:**
```markdown
# 渡劫期大圆满程序员飞升记

## 第X章：四字标题
```

3. **Scene breaks:** Use `---` on its own line between scenes/locations.

4. **Code blocks as worldbuilding:** System logs, function signatures, encrypted comments, API responses, and configuration files are all diegetic elements — they advance plot and reveal character. Every code block must serve narrative purpose.

5. **Prose style:**
   - Chinese prose with technical precision
   - Characters speak in distinct voices (陆凡: dry/deadpan, 苏晴雪: cool/precise, 陆小染: warm/direct, 墨渊: diplomatic/encrypted, 玄冥: slow/kindly/terrifying, 白无尘: almost silent)
   - Humor comes from programmer-culture collisions with cultivation tropes
   - Emotional beats land through restraint — the biggest moments are understated

6. **Chapter ending:** Close with `*（第X章·完）*` followed by a next-chapter preview block:
```markdown
*下一章预告：「四字标题」。Brief hook — 2-3 sentences max. End with a tease.*
```

7. **Final chapter:** Use `*（终章·完）*` then a book afterword if appropriate. File suffix: `-fin.md`.

## Character Mapping

| Character | Role | Vibe | Key Thread |
|-----------|------|------|------------|
| 陆凡 | 第十三代首席架构师 | 面瘫/死水/被代码磨平，偶尔笑 | 重构九天，从一个人到不再一个人 |
| 苏晴雪 | 北极冰宫少主/前端天花板 | 冷面毒舌完美主义 | 版本协商，工伤险，TODO: follow up |
| 陆小染 | 天机之钥/陆凡师妹 | 天赋炸裂，合体中期 | 不是复制品，是彼此的校验码 |
| 墨渊 | 南海首席架构师 | 外交家外壳+偏执狂内核 | TODO注释修复者，在所有人背后铺路 |
| 白无尘 | 第十二代关门弟子 | 沉默到近乎哑巴 | 卧底三年，不说但都做了 |
| 孟小舟 | 墨渊弟子/天才少年 | 清澈坚定 | 选了背面那行字 |
| 张小松 | 掌门首席跑腿弟子 | 凡人视角，喜剧担当 | 涨薪申请书 |
| 第十二代 | 陆凡师父 | 温和而深不可测 | 仙界控制台前等了三年 |
| 天机子 | 初代架构师 | 狂妄又恐惧的年轻人 | 把选择留给后来者 |
| 玄冥老祖 | 天机子魔气分身 | 慈祥的恐怖 | 三千年养莲花，不是反派是备份 |

## Pitfalls

- **Forgetting continuity.** If you don't re-read prior chapters, you will contradict established facts (e.g., character locations, power levels, who knows what). Always full re-read before writing.
- **Over-explaining emotional beats.** The style trusts the reader. "洞府里沉默了很长时间" hits harder than three paragraphs of inner monologue. Show the silence, not the analysis of the silence.
- **Code blocks without narrative purpose.** If a syslog or function signature doesn't reveal character or advance plot, cut it. Every code block must be diegetic.
- **Breaking the chapter preview promise.** If the prior chapter's preview teased a specific reveal, the next chapter must deliver it. The reader waited — don't bait-and-switch.
