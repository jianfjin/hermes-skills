# xAI (Grok) Provider Quirks — Council Profiles

## Summary

xAI's Grok models use the `codex_responses` transport mode (not standard chat_completions). This means:
- Request format is OpenAI Responses API, not Chat Completions
- `reasoning.effort` is always sent as a parameter unless explicitly disabled
- API key resolution differs from other providers

## API Key Configuration

**Only `XAI_API_KEY` env var works.** Neither `model.api_key` in profile config nor `providers.xai.api_key` in global config were sufficient during testing (2026-05-24).

### Working setup

```bash
# Add to ~/.hermes/.env:
XAI_API_KEY="xai-xxxxxxxxxxx"
```

```bash
# Profile model config (no api_key needed — env var handles it):
feifei config set model.default grok-4.20-0309-reasoning
feifei config set model.provider xai
```

Or for the default profile (峰哥):
```bash
hermes config set model.default grok-4.20-0309-reasoning
hermes config set model.provider xai
# reasoning_effort can stay at medium for the reasoning model
```

## `reasoningEffort` Parameter Mismatch

### Symptoms

When using `grok-4.20-0309-non-reasoning` (or any non-reasoning variant) with `reasoning_effort` set:
```
HTTP 400: Model grok-4.20-0309-non-reasoning does not support parameter reasoningEffort.
```

### Root Cause

The Codex transport (`agent/transports/codex.py`, lines 80-108) defaults `reasoning_effort = "medium"` and always sends `kwargs["reasoning"] = {"effort": reasoning_effort}` for xAI models when `reasoning_enabled` is True:

```python
# codex.py:80
reasoning_effort = "medium"
reasoning_enabled = True
reasoning_config = params.get("reasoning_config")
if reasoning_config and isinstance(reasoning_config, dict):
    if reasoning_config.get("enabled") is False:
        reasoning_enabled = False
    elif reasoning_config.get("effort"):
        reasoning_effort = reasoning_config["effort"]

# codex.py:106 — always sent for xAI
if reasoning_enabled and is_xai_responses:
    kwargs["include"] = ["reasoning.encrypted_content"]
    kwargs["reasoning"] = {"effort": reasoning_effort}
```

Non-reasoning models (`grok-4.20-0309-non-reasoning`) reject any `reasoning.*` parameters outright because they have no chain-of-thought system.

### Fixes

| Approach | How | When |
|----------|-----|------|
| **Use reasoning model** | Set model to `grok-4.20-0309-reasoning` instead | Preferred — reasoning is useful |
| **Disable reasoning** | Set `reasoning_effort: none` in profile config → produces `reasoning_config: {"enabled": False}` → skips param | For non-reasoning models or when thinking overhead unwanted |

The `reasoning_effort: none` config value propagates through `hermes_constants.parse_reasoning_effort()`:

```python
# hermes_constants.py:194-209
parse_reasoning_effort("none")    → {"enabled": False}
parse_reasoning_effort("medium")  → {"enabled": True, "effort": "medium"}
parse_reasoning_effort("")        → None  (caller uses default "medium")
```

So setting `reasoning_effort: ''` (empty string) does NOT disable it — the codex transport falls through to the default `"medium"`. Only an explicit `"none"` triggers `reasoning_enabled = False`.

## Timing Observations

First observed timing for `grok-4.20-0309-reasoning` via xAI (2026-05-24, simple intro query):
- First attempt (with `XAI_API_KEY` env var): ~8 seconds, 2 rounds
- Second attempt (relationship question): ~11 seconds, 2 rounds
- No tool calls in either test (simple Q&A)

Compare with known timings:
- deepseek-v4-flash: ~34-40s
- deepseek-v4-pro: ~40s-1m40s
- kimi-k2.6: ~40-100s

Grok appears significantly faster for simple queries, but this needs more data points with actual tool-calling debates.

## xAI Provider Profile

Located at `~/.hermes/hermes-agent/plugins/model-providers/xai/__init__.py`:

```python
xai = ProviderProfile(
    name="xai",
    aliases=("grok", "x-ai", "x.ai"),
    api_mode="codex_responses",   # ← Uses Responses API, NOT chat completions
    env_vars=("XAI_API_KEY",),    # ← Only recognizes this env var
    base_url="https://api.x.ai/v1",
    auth_type="api_key",
)
```

## Known Differences from Other Providers

| Aspect | xAI/Grok | Others |
|--------|----------|--------|
| API transport | `codex_responses` (Responses API) | `chat_completions` (OpenAI format) |
| Max output tokens | Via `max_output_tokens` param | Via `max_tokens` param |
| Reasoning header | `x-grok-conv-id` for session | Various |
| API key source | `XAI_API_KEY` env var only | Flexible (config, multiple env vars) |
| `reasoning.effort` | Always sent if enabled; rejected by non-reasoning models | Per-provider handling |
