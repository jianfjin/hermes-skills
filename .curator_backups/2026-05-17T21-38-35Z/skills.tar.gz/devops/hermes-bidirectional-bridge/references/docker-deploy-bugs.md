# Docker Deployment Bugs — SCAILED Pathfinder

7 deployment-layer bugs discovered during e2e Docker Compose verification (2026-05-17).
All were application-layer-passing but deployment-layer-failing.
Lesson: e2e verification must include BOTH application-layer AND deployment-layer.

## Bug Summary

| # | Symptom | Root Cause | Fix |
|---|---------|-----------|-----|
| 1 | uvicorn crash on startup | `pip install --no-deps` skipped runtime dependencies | Remove `--no-deps` from Dockerfile.backend |
| 2 | Python import errors | `pip --prefix=/install` not in sys.path | Add `/install/lib/python3.12/site-packages` to PYTHONPATH |
| 3 | Traefik shows no Docker providers | v3.3 Docker API client too old (v1.24 vs API v1.44) | Upgrade to `traefik:v3.7` |
| 4 | All HTTP routes return 404 | `ratelimit@docker` middleware self-references + gets filtered by Traefik | Remove the ratelimit middleware entirely |
| 5 | Backend unreachable (no route) | Backend container missing `traefik.enable=true` label | Add the label to backend service |
| 6 | `/api` routes return Traefik dashboard | `--api.insecure=true` creates internal dashboard at priority 9e18 that hijacks `/api` prefix | Remove `--api.insecure` flag |
| 7 | Frontend healthcheck fails `unhealthy` | `wget localhost` resolves to IPv6, nginx only listens on IPv4 | Change healthcheck to `wget http://127.0.0.1/health` |

## Key Files Affected

- `deploy/docker-compose.yml` — bugs 3, 4, 5, 6
- `deploy/Dockerfile.backend` — bugs 1, 2
- `deploy/Dockerfile.frontend` — bug 7

## Prevention

- Always run `docker compose up -d && docker compose ps` after config changes
- Check `docker compose logs <service>` for each container
- Verify `curl http://localhost/health` returns 200
- Verify `curl http://localhost/v1/questionnaires` returns 200 (with auth header)
- Healthchecks should use explicit IP addresses (127.0.0.1), not hostnames
