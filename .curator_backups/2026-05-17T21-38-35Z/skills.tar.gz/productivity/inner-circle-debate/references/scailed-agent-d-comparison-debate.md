# Agent-D Comparison Debate — SCAILED WP4 (2026-05-15)

8-seat council debate comparing the Parliament's design against an independent
Agent-D proposal. This is the largest debate to date with the most significant
outcome: the Parliament's design was confirmed but enriched with Agent-D's
strongest contributions.

## Context

The Emperor commissioned another agent (Agent-D) to produce an independent
SCAILED WP4 design (11 documents in docs/). The designs had major divergences:
Neo4j vs PG+AGE, K8s vs Docker Compose, AI Copilot vs deterministic engine,
6-module SaaS vs 3-module D4.1 scope.

## Debate Structure

- **Seats**: Musk, Linus, Dijkstra, Guido, Xiaolong, Xuefeng, Jobs, Jensen (8 seats)
- **Models**: 4 kimi-k2.6 (Musk/Guido/Dijkstra/Jobs) + 3 deepseek-v4-pro (Linus/Xiaolong) + 1 deepseek-v4-flash (Xuefeng) + 1 deepseek-v4-flash (Jensen)
- **Duration**: ~17 minutes (kimi agents dominated latency; Musk took 16m33s)
- **Outcome**: 8/8 unanimous fusion verdict

## Key Pattern: Market Data as Debate Input

Before the debate, the CTO conducted a market data investigation:
- GitHub stars: React 245K vs Vue 54K
- npm weekly downloads: React 132M vs Vue 12M
- EU job market: React dominates 5-8×
- German hospital IT: 85% run VMs, not K8s

This data was critical — it corrected the Parliament's earlier assumption that
Vue was the right choice for CHARITE (a German institution). The lesson: when
a design decision involves the target user's ecosystem, get hard market data
before debating.

## Key Pattern: Budget-Constrained Scope Reduction

Agent-D's design was a strong product blueprint but cost €260K-320K — exceeding
the €145K budget by 80-120%. Xuefeng's cost audit was the deciding factor.
Lesson: always include a budget-realist seat (Xuefeng/CSA) in scope debates.

## Key Pattern: Absorb vs Reject Framework

The fusion verdict explicitly categorized Agent-D's proposals:
- **Absorbed**: mock-data-first, data contracts, product UX, ontology
- **Rejected**: Neo4j, K8s, AI Copilot, 6-module scope, multi-repo

This absorb/reject framework prevents the "throw everything out" reflex when
reviewing external designs.

## Files

- `docs/01-11` — Agent-D's original 11 documents
- `council_debate_20260513/00_council_resolution.md` — Fusion verdict
- `council_debate_20260513/architecture-spec.html §02e` — Comparison table
